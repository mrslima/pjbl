#include "tabela.h"

bool writeData(char *filename, type_actors *data, int total) {
  FILE *file;
  file = fopen(filename, "wb");

  if (file == NULL) {
    puts("Erro! Não foi possível abrir o arquivo.");
    return false;
  }

  if (fwrite(&total, sizeof(int), 1, file) != 1)
    return false;

  if (fwrite(data, sizeof(type_actors), total, file) != total)
    return false;

  if (fclose(file) == EOF)
    return false;

  return true;
}
