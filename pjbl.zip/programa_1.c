#include "tabela.h"


int main(int argc, char *argv[]) {
  setlocale(LC_ALL, "Portuguese");

  //    if (!(argc < 1)){
  //        puts("Nenhum arquivo foi passado como parâmetro!");
  //        return 1;
  //    } else if (argc > 2) {
  //        puts("Informe apenas um parâmetro");
  //        return 1;
  //    }

  //    char *path = argv[1];

  type_actors *arr_actors;
  arr_actors = malloc(sizeof(type_actors) * ARRAY_SIZE);


  if (readTextFile("atores.txt", arr_actors)) {
    puts("Read data OK.\n");
  } else {
    puts("Error reading to file.\n");
    return 1;
  }

  if (writeData("binAtores.bin", arr_actors, ARRAY_SIZE)) {
    puts("Write data OK.\n");
  }
  else {
    puts("Error writing to file.\n");
    return 1;
  }

   free(arr_actors);
  
  // system("clear");
  // puts("SEUS DADOS");
  // for (int i = 0; i < ARRAY_SIZE; i++) {
  //   printf("----- Pessoa %d -----\n", i);
  //   printf("\tGenero: %d\n", arr_actors[i].genero);
  //   printf("\tNome: %s\n", arr_actors[i].nome);
  //   printf("\tIdade: %d\n", arr_actors[i].idade);
  //   printf("\tAltura: %lf\n", arr_actors[i].altura);
  //   printf("\tMes nasc: %d\n", arr_actors[i].mes);
  //   printf("\tFama: %d\%\n", arr_actors[i].fama);
  // }

  return 0;
}
